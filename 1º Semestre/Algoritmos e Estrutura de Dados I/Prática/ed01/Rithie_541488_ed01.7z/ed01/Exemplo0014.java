/**
 * Estudo Dirigido 14
 *
 * Trabalho Pratico: Guia 01
 *
 * Nome: Rithie Natan   Vers�o: 0.1
 * Matr�cula: 541488    Data: 14/02/2016
 *
 *@version 14
*/

import IO.*;

public class Exemplo0014
{
   public static void main (String[] args)
   {
      int y;
      int x;
      
      y = IO.readint("Digite um valor inteiro: ");
      
      x = IO.readint("Digite um valor inteiro: ");
      
      IO.println ( "x = " + x );
      
      IO.println ( "y = " + y );
   }
}
