/**
 * Estudo Dirigido 06
 *
 * Trabalho Pratico: Guia 01
 *
 * Nome: Rithie Natan   Vers�o: 0.1
 * Matr�cula: 541488    Data: 14/02/2016
 *
 *@version 06
*/

import IO.*;

public class Exemplo0006
{
   public static void main (String[] args)
   {
      char x;
      
      x = 'A';
      
      x = IO.readchar ("Entrar com um caractere: ");
      
      IO.println ( "x=" + x );
   }
}
