/**
 * Estudo Dirigido 10
 *
 *
 * Nome: Rithie Natan   Vers�o: 0.1
 * Matr�cula: 541488    Data: 12/04/2016
 
   Exemplo0181
 
 *@version 01
*
*/

/**
 * Exemplo0181
 *
 * @author
 * @version 01
 */
// ---------------------------------------------- dependencias
import IO.*;
// ---------------------------------------------- definicao de classe auxiliar
/**
 * Classe para tratar arranjo de inteiros.
 */
class Arranjo
{
 /**
 * armazenador generico dos dados
 */
   public Object [ ] tabela;
 /**
 * construtor padrao
 */
   public Arranjo ( )
   {
      tabela = null;
   } // fim construtor padrao
} // fim da classe Arranjo
// ---------------------------------------------- definicao da classe principal
public class Exemplo0181
{
// ---------------------------------------------- definicao de metodo auxiliar
 /**
 * Testar defini��es de arranjo usando classe.
 */
   public static void metodo01 ( )
   {
   // 1. definir dados
      Arranjo a1 = null; // nao existe objeto
      Arranjo a2 = new Arranjo ( ); // existe objeto (sem dados, no momento)
   // 2. identificar
      IO.println ( "Definicoes de arranjo" );
   // 3. testar as definicoes de arranjo
      if ( a1 == null )
      {
         IO.println ( "Arranjo a1 nulo" );
      }
      else
      {
         IO.println ( "Arranjo a1 nao nulo" );
      } // fim se
      if ( a2 == null )
      {
         IO.println ( "Arranjo a2 nulo" );
      }
      else
      {
         IO.println ( "Arranjo a2 nao nulo" );
      } // fim se
   // 5. encerrar
      IO.println ( );
      IO.pause ( "Apertar ENTER para continuar." );
   } // fim metodo01( )
// ---------------------------------------------- definicao do metodo principal
 /**
 * main() � metodo principal
 */
   public static void main ( String [ ] args )
   {
   // identificar
      IO.println ( "EXEMPLO0181 - Programa em Java" );
      IO.println ( "Autor: ________________________" );
   // executar o metodo auxiliar
      metodo01 ( );
   // encerrar
      IO.pause ( "Apertar ENTER para terminar." );
   } // fim main( )
} // fim class Exemplo0161