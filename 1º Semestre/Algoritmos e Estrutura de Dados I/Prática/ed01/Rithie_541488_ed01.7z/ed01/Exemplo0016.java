/**
 * Estudo Dirigido 16
 *
 * Trabalho Pratico: Guia 01
 *
 * Nome: Rithie Natan   Vers�o: 0.1
 * Matr�cula: 541488    Data: 14/02/2016
 *
 *@version 16
*/

import IO.*;

public class Exemplo0016
{
   public static void main (String[] args)
   {
      char x, y;
      
      y = IO.readchar("Digite um caracter: ");
      
      x = IO.readchar("Digite um caracter: ");
      
      IO.println ( "x = " + x );
      
      IO.println ( "y = " + y );
      
      IO.println ( "x = " + x + " y = " + y );
   }
}
