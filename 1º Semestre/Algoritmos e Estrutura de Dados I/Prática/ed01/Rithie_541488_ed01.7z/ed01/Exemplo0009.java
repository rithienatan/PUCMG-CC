/**
 * Estudo Dirigido 09
 *
 * Trabalho Pratico: Guia 01
 *
 * Nome: Rithie Natan   Vers�o: 0.1
 * Matr�cula: 541488    Data: 14/02/2016
 *
 *@version 09
*/

import IO.*;

public class Exemplo0009
{
   public static void main (String[] args)
   {
      String x;
   
      x = "43.21"; 
   
   
      x = IO.readString ( "Entrar com uma cadeia de caracteres: " );         
      IO.println ( "x=" + x );  
   }
}
