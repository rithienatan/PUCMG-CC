/**
 * Estudo Dirigido 07
 *
 * Trabalho Pratico: Guia 01
 *
 * Nome: Rithie Natan   Vers�o: 0.1
 * Matr�cula: 541488    Data: 14/02/2016
 *
 *@version 07
*/

import IO.*;

public class Exemplo0007
{
   public static void main (String[] args)
   {
      double x;
   
      x = 43.21; 
   
      x = IO.readdouble ( "Entrar com um valor real: ");   
      
      IO.println ( "x=" + x );  
   }
}
