
echo "Digite seu nome:"
read USERNAME

echo "Digite sua idade:"
read AGE

echo "$USERNAME tem $AGE anos de idade"

