/**
 * Estudo Dirigido E1
 *
 * Trabalho Pratico: Guia 01
 *
 * Nome: Rithie Natan   Vers�o: 0.1
 * Matr�cula: 541488    Data: 14/02/2016
 *
 *@version E1
*/

import IO.*;

public class E1
{
   public static void main (String[] args)
   {
      char x;
      int y;
      
      x = IO.readchar("Entre com uma sequ�ncia de digitos: ");
      
      y = (int)x;
   
      IO.println ( "x = " + x );
      
      IO.println ( "y = " + y );
   }
}
