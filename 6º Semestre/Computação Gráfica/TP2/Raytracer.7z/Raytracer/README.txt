Neste programa foi implementado:
 . C�mera - classe Camera
 . Fontes de Luzes - a classe chamada light, al�m de ser tratada tamb�m por vir de outros objetos
 . Pigmentos - definida as cores no metodo main e tamb�m � setada na classe cor
 . cor de fundo definida como preto
 . tamanho da janela: 640 x 480 fixo - est� no metodo main
 . objetos s�o esferas - foi criado uma classe separada chamada Sphere

 Adicional:
 . anti-aliasing - est� no metodo main