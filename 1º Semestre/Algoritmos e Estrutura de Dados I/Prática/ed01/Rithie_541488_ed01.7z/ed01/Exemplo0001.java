/**
 * Estudo Dirigido 01
 *
 * Trabalho Pratico: Guia 01
 *
 * Nome: Rithie Natan   Vers�o: 0.1
 * Matr�cula: 541488    Data: 14/02/2016
 * 
 *@version 01
*/

import IO.*;
// ---------------------------------------------- definicao da classe principal
public class Exemplo0001
{
// ---------------------------------------------- definicao de metodos
// ---------------------------------------------- definicao do metodo principal
 /**
 * main() � metodo principal
 */
   public static void main ( String [ ] args )
   {
      IO.println ( "EXEMPLO0001 - Programa em Java" );
      IO.println ( "Autor: ________________________" );
      IO.pause ( "Apertar ENTER para terminar." );
   } // fim main( )
} // fim class Exemplo0001
// ---------------------------------------------- documentacao complementar
//
// ---------------------------------------------- historico
//
// Versao Data Modificacao
// 0.1 __ / __ esboco
//
// ---------------------------------------------- testes
//
// Versao Teste
// 0.1 01. ( OK ) identificacao de programa