/**
 * Estudo Dirigido 15
 *
 * Trabalho Pratico: Guia 01
 *
 * Nome: Rithie Natan   Vers�o: 0.1
 * Matr�cula: 541488    Data: 14/02/2016
 *
 *@version 15
*/

import IO.*;

public class Exemplo0015
{
   public static void main (String[] args)
   {
      double x, y;
      
      y = IO.readdouble("Digite um valor inteiro: ");
      
      x = IO.readdouble("Digite um valor inteiro: ");
      
      IO.println ( "x = " + x );
      
      IO.println ( "y = " + y );
      
      IO.println ( "x = " + x + " y = " + y );
   }
}
