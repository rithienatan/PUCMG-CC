/**
 * Estudo Dirigido 04
 *
 * Trabalho Pratico: Guia 01
 *
 * Nome: Rithie Natan   Vers�o: 0.1
 * Matr�cula: 541488    Data: 14/02/2016
 * 
 *@version 04
*/

import IO.*;
// ---------------------------------------------- definicao da classe principal
public class Exemplo0004
{
// ---------------------------------------------- definicao de metodos
// ---------------------------------------------- definicao do metodo principal
 /**
 * main() � metodo principal
 */
   public static void main ( String [ ] args )
   {
   // definir dado
      int x = 0;
      IO.println ( "EXEMPLO0004 - Programa em Java" );
      IO.println ( "Autor: ________________________" );
      IO.println ( "x (inicial) = " + x ); // exibir valor do dado antes de modificar
      x = 5; // atribuir valor ao dado
      IO.println ( "x ( atual ) = " + x ); // exibir valor do dado depois de modificar
      IO.pause ( "Apertar ENTER para terminar." );
   } // fim main( )   
} // fim class Exemplo0002
// ---------------------------------------------- documentacao complementar
//
// ---------------------------------------------- historico
//
// Versao Data Modificacao
// 0.1 01/08 esboco
// 0.2 01/08 mudan�a de vers�o

// ---------------------------------------------- testes
//
// Versao Teste
// 0.1 01. ( OK ) identificacao de programa
// 0.2 01. ( OK ) identificacao de programa
// 02. ( OK ) introdu��o de dado inteiro