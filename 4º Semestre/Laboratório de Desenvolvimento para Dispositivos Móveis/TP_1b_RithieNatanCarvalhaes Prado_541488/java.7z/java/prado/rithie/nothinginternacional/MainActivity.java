package prado.rithie.nothinginternacional;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.Calendar;
import java.util.Date;
import  java.util.GregorianCalendar;
import java.lang.Math;

public class MainActivity extends AppCompatActivity {

    ImageButton imageButton, imageButton2, imageButton3, imageButton4;
    TextView caixaDeTexto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageButton = (ImageButton) findViewById(R.id.imageButton);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                caixaDeTexto = (TextView) findViewById(R.id.myText);
                caixaDeTexto.setText(R.string.brasil);
            }
        });

        imageButton2 = (ImageButton) findViewById(R.id.imageButton2);
        imageButton2.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                caixaDeTexto = (TextView) findViewById(R.id.myText);
                caixaDeTexto.setText(R.string.usa);
            }
        });

        imageButton3 = (ImageButton) findViewById(R.id.imageButton3);
        imageButton3.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                caixaDeTexto = (TextView) findViewById(R.id.myText);
                caixaDeTexto.setText(R.string.italy);
            }
        });

        imageButton4 = (ImageButton) findViewById(R.id.imageButton4);
        imageButton4.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                caixaDeTexto = (TextView) findViewById(R.id.myText);
                caixaDeTexto.setText(R.string.spain);
            }
        });
    }

    Calendar c = Calendar.getInstance();

    protected void onStart() {
        super.onStart();

        caixaDeTexto = (TextView) findViewById(R.id.dataStartView);
        caixaDeTexto.setText("" + c.getTime());
    }//end onStart()

    long inicio = c.getTimeInMillis();
    protected void onResume(){
        super.onResume();
        Calendar c = Calendar.getInstance();
    }//onResume()

    protected void onPause() {
        Calendar end = Calendar.getInstance();

        super.onPause();

        long fim = end.getTimeInMillis();

        long tempo = fim-inicio;

        if((tempo/1000) <= 60 ) {
            long time = tempo/1000;
            caixaDeTexto = (TextView) findViewById(R.id.timeOnStopAndPauseView);
            caixaDeTexto.setText(getString(R.string.backPausa) + " " + Math.round(time) + " seg");
        }
        else if((tempo/1000000) <= 60) {
            long time = tempo/1000000;
            caixaDeTexto = (TextView) findViewById(R.id.timeOnStopAndPauseView);
            caixaDeTexto.setText(getString(R.string.backPausa) + " " + Math.round(time) + " min");
        }
        else {
            long time = tempo/1000000000;
            caixaDeTexto = (TextView) findViewById(R.id.timeOnStopAndPauseView);
            caixaDeTexto.setText(getString(R.string.backPausa) + " " + Math.round(time) + " horas");
        }
    }//end onPause()

    protected  void onRestart(){
        super.onRestart();
    }//end onRestart()

    protected void onStop(){
        Calendar end = Calendar.getInstance();

        super.onStop();

        long fim = end.getTimeInMillis();

        long tempo = fim-inicio;

        if((tempo/1000) <= 60 ) {
            long time = tempo/1000;
            caixaDeTexto = (TextView) findViewById(R.id.timeOnStopAndPauseView);
            caixaDeTexto.setText(getString(R.string.backStop) + " " + Math.round(time) + " seg");
        }
        else if((tempo/1000000) <= 60) {
            long time = tempo/1000000;
            caixaDeTexto = (TextView) findViewById(R.id.timeOnStopAndPauseView);
            caixaDeTexto.setText(getString(R.string.backStop) + " " + Math.round(time) + " min");
        }
        else {
            long time = tempo/1000000000;
            caixaDeTexto = (TextView) findViewById(R.id.timeOnStopAndPauseView);
            caixaDeTexto.setText(getString(R.string.backStop) + " " + Math.round(time) + " horas");
        }
    }//end onStop()
}