
echo "Digite seu nome:"
read USERNAME

echo "Digite sua idade:"
read AGE

if [ $AGE -le 12 ]; then
    echo "Infancia"
else
    if [ $AGE -le 18 ]; then
        echo "Adolescencia"
    else
        echo "Vida adulta"
    fi
fi
