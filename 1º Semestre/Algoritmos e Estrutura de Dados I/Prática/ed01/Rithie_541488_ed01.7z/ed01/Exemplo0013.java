/**
 * Estudo Dirigido 13
 *
 * Trabalho Pratico: Guia 01
 *
 * Nome: Rithie Natan   Vers�o: 0.1
 * Matr�cula: 541488    Data: 14/02/2016
 *
 *@version 13
*/

import IO.*;

public class Exemplo0013
{
   public static void main (String[] args)
   {
      String x;
      int y = 5;
      double z = 4;
      boolean w;
      
      w = (y > z);
      
      x = ""+(y > z);
      
      IO.println ( "x = " + x );
      
      IO.println ( "y = " + y );
      
      IO.println ( "y = " + z );
      
      IO.println ( "y = " + w );
   }
}
