
if [ -f $1 ]; then
    echo "Arquivo encontrado"
else
    echo "Arquivo NAO encontrado"
fi
